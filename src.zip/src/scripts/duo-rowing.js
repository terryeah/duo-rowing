import '../styles/duo-rowing.scss';
import './components/nav'
