export default function Footer(){
    return `
        <footer>
            <div>Test</div>
        </footer>
    `;
}
