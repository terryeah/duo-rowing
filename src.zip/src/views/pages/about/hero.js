export default function Hero() {
    const aboutHero = document.createElement('div');

    aboutHero.innerHTML = '<h1>About Hero</h1>';

    return aboutHero;
}
