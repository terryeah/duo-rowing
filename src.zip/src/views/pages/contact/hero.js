export default function Hero() {
    const contactHero = document.createElement('div');

    contactHero.innerHTML = '<h1>Contact Hero</h1>';

    return contactHero;
}
