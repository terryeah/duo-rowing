export default function Hero() {
    const productHero = document.createElement('div');

    productHero.innerHTML = '<h1>Product Hero</h1>';

    return productHero;
}
